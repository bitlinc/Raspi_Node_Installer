#!/usr/bin/env bash
import wget, getpass, os, sys, stat

# GUIZERO import statement
from guizero import App, Combo, Text, CheckBox, ButtonGroup, PushButton, info, MenuBar, Window, Picture, Box

# Global Arguments Used
username = getpass.getuser()

##### Menu Functions
# Exit Function in the menu - closes out the app completly
def exit_function():
    print("Exit Script Completely")
    do_this_when_closed()

    # Ask the user if they really want to update Bitcoin Installer
def update_function():
    if app.yesno("A question...", "Do you want to update the Bitcoin Insaller Application?"):
        import subprocess
        subprocess.check_call('/Users/'+username+'/Bitlinc/Updater/update_script')
        app.warn("Update Successfull!", "Click 'OK' to close application and then reopen Bitcoin Installer from the desktop shortcut")
        app.destroy() 

# Version Function in the menu - displays the version of the installer in the GUI
def version_function():
    print("Version function")    

# Begining of GUI
app = App( title="Welcome Screen", height=600, width=600, layout="grid")
# Create in the 'Menu Bar' these options 'exit script', 'update script', and 'version' and call the function for each when selected
menubar = MenuBar(app,
                  toplevel=["Exit Bitcoin Installer", "Update", "Check Bitlinc Installer Version"],
                  options=[
                      [ ["Close and Exit installer", exit_function], ],
                      [ ["Update Bitlinc Installer Application", update_function], ],
                      [ ["Verify Bitlinc Installer Version", version_function], ]
                  ])

########## Windows ##########

##### Main Window
start_page_picture = Picture(app, image='/Users/'+username+'/Bitlinc/Images/bitcoin_installer_gui_background.jpeg', height=350, width=600, grid=[0,3], align="top")
## Functions - Main Window
# Start Install button loading the page from the combo (drop down) on the main page
def start_button_start_page_function():
    user_choosen_install_type_function(result)
# Set variable depending on user choose of install type
def you_chose_install_type(selected_value):
    if selected_value == "Step 1: Install Bitcoin GUI Wallet - Download / SYNC blockchain":
        result.value = "1"
        return result
    elif selected_value == "Step 2: Create Rapsberry Pi Bitcoin Node and Electrum Wallet":
        result.value = "2"
        return result
    else:
        result.value = "3"
        return result
# Open Bitcoin GUI Wallet Install Window
def user_choosen_install_type_function(result):
    if result.value == "1":
        bitcoin_GUI_wallet_window.show()
    elif result.value == "2":
        raspi_install_window.show()
    else:
        custom_install_window.show()            
# Ask the user if they really want to close the window
def do_this_when_closed():
    if app.yesno("Close", "Do you want to quit?"):
        app.destroy()
## Buttons - Main Window
start_button_start_page = PushButton(app, text="Confirm Install Type", command=start_button_start_page_function, grid=[0,6])
update_bitcoin_installer = PushButton(app, text="Check For Software Update", command=update_function, grid=[0,7])
## Text - Main Window
start_page_text = Text(app, text="Bitcoin Install Program", grid=[0,2], size=55, font="Gill Sans")
start_page_text_step1 = Text(app, text="Choose What Type Of Install that you want", grid=[0,4], size=30, font="Gill Sans")
#title_start_page_box = Text(title_box, text="title", align="left")
## Combo - Main Window
combo = Combo(app, options=["Start Here", "Step 1: Install Bitcoin GUI Wallet - Download / SYNC blockchain", "Step 2: Create Rapsberry Pi Bitcoin Node and Electrum Wallet", "Advanced Users: Custom install applications"], grid=[0,5], command=you_chose_install_type, width=55)
result = Text(app, grid=[0,7], size=15, font="Gill Sans", visible=False)

##### Step 1: Install Bitcoin GUI Wallet Window

## Functions - Step 1: Install Bitcoin GUI Wallet Window
# Run Bitcoin Installer Script - Step 1: Install Bitcoin GUI Wallet Window
def install_bitcoin_GUI_wallet_macOS_linux():
    import subprocess
    subprocess.check_call(['/Users/'+username+'/Bitlinc/Scripts/Bitcoin_Installer_Step1', bitcoin_network_choice.value, bitcoin_tor_choice.value])
# Close window - Step 1: Install Bitcoin GUI Wallet Window      
def close_bitcoin_GUI_wallet_window():
    bitcoin_GUI_wallet_window.destroy()    
## Window - Step 1: Install Bitcoin GUI Wallet Window
bitcoin_GUI_wallet_window = Window(app, title="Install Bitcoin Graphical Wallet - SYNC Blockchain", height=300, width=440, layout="grid", visible=False)

## Text - Step 1: Install Bitcoin GUI Wallet Window
step1_window_title = Text(bitcoin_GUI_wallet_window, text="Install Bitcoin Node - SYNC Blockchain", grid=[0,0], size=25, font="Gill Sans")
step1_window_line= Text(bitcoin_GUI_wallet_window, text="-----------------------------------------", grid=[0,1], size=16, font="Gill Sans")
step1_window_bitcoin_network = Text(bitcoin_GUI_wallet_window, text=" - What Bitcoin networks do you want to SYNC?", grid=[0,2], size=20, font="Gill Sans", align="left")
step1_window_line2= Text(bitcoin_GUI_wallet_window, text="-----------------------------------------", grid=[0,7], size=13, font="Gill Sans")
step1_window_line2= Text(bitcoin_GUI_wallet_window, text="*****", grid=[0,4], size=20, font="Gill Sans")
step1_window_bitcoin_tor = Text(bitcoin_GUI_wallet_window, text=" - Do you want Bitcoin to run only over Tor?", grid=[0,5], size=20, font="Gill Sans", align="left")

## ButtonGroup - Step 1: Install Bitcoin GUI Wallet Window
bitcoin_network_choice = ButtonGroup(bitcoin_GUI_wallet_window, options=["Mainnet & Testnet", "Mainnet", "Testnet"], selected="Mainnet & Testnet", grid=[0,3], horizontal="False", align="left")
bitcoin_tor_choice = ButtonGroup(bitcoin_GUI_wallet_window, options=["No", "Yes"], selected="No", grid=[0,6], horizontal="False", align="left")
   
## Buttons - Step 1: Install Bitcoin GUI Wallet Window
install_bitcoin_GUI_wallet_macOS_linux_button = PushButton(bitcoin_GUI_wallet_window, text="Start Install", command=install_bitcoin_GUI_wallet_macOS_linux, grid=[0,9])
close_button = PushButton(bitcoin_GUI_wallet_window, text="Stop and Close Install", command=close_bitcoin_GUI_wallet_window, grid=[0,10], align="bottom")
#close_button = PushButton(bitcoin_GUI_wallet_window, text="Stop and Close Install", command=print_arg, grid=[0,10], align="bottom")

## Install Arguments
btc_network_choice = bitcoin_network_choice.value
btc_tor_choice = bitcoin_tor_choice.value

##### Step 2: Create Rapsberry Pi Bitcoin Node and Electrum Wallet Window
raspi_install_window = Window(app, title="Prepair Rapsberry Pi for full Bitcoin and Electrum Install", height=500, width=650, layout="grid", visible=False)

##### Custom Install Window
custom_install_window = Window(app, title="Custom Install - Advanced Users Only", height=500, width=650, layout="grid", visible=False)      

##### UUID Drive Window
# Opens a new window and get the displays the UUID's of connected drives to the computer
# Asigned the global argument $1 to the users UUID
get_drive_uuid_window = Window(app, title="Install Bitcoin", height=500, width=650, layout="grid", visible=False)


# When the user tries to close the window, run the function do_this_when_closed()
app.when_closed = do_this_when_closed


# End of GUI
app.display()